```python
from array import*
arrayScore = array('i',[100,108,112,115,150,178,143,132,190,235,253,298,328,390,257,288,393,425,458,450,473,333,452,490,495,488,543,532,590,605])
for x in arrayScore:
    print(x)

```

    100
    108
    112
    115
    150
    178
    143
    132
    190
    235
    253
    298
    328
    390
    257
    288
    393
    425
    458
    450
    473
    333
    452
    490
    495
    488
    543
    532
    590
    605
    


```python
import numpy as np
days = np.arange(1,31)
print(days)
```

    [ 1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24
     25 26 27 28 29 30]
    


```python
import matplotlib.pyplot as plt
import numpy as np
y=array('i',[100,108,112,115,150,178,143,132,190,235,253,298,328,390,257,288,393,425,458,450,473,333,452,490,495,488,543,532,590,605])
x= np.arange(1,31)
plt.xlim(0,30)
plt.ylim(100,1000)
plt.xlabel('score')
plt.ylabel('days')
plt.title('dictionary game')
plt.plot(x,y)
plt.show()
```


![png](output_2_0.png)



```python
import numpy as np
arrayScore = array('i',[100,108,112,115,150,178,143,132,190,235,253,298,328,390,257,288,393,425,458,450,473,333,452,490,495,488,543,532,590,605])
print("Score :",arrayScore)
print("mean of Score :",np.mean(arrayScore))
```

    Score : array('i', [100, 108, 112, 115, 150, 178, 143, 132, 190, 235, 253, 298, 328, 390, 257, 288, 393, 425, 458, 450, 473, 333, 452, 490, 495, 488, 543, 532, 590, 605])
    mean of Score : 333.46666666666664
    


```python
import numpy as np
arrayScore = array('i',[100,108,112,115,150,178,143,132,190,235,253,298,328,390,257,288,393,425,458,450,473,333,452,490,495,488,543,532,590,605])
print("Score :",arrayScore)
print("median of Score :",np.median(arrayScore))
```

    Score : array('i', [100, 108, 112, 115, 150, 178, 143, 132, 190, 235, 253, 298, 328, 390, 257, 288, 393, 425, 458, 450, 473, 333, 452, 490, 495, 488, 543, 532, 590, 605])
    median of Score : 330.5
    


```python
import numpy as np
arrayScore = array('i',[100,108,112,115,150,178,143,132,190,235,253,298,328,390,257,288,393,425,458,450,473,333,452,490,495,488,543,532,590,605])
maxElement = np.amax(arrayScore)
minElement = np.amin(arrayScore)
print('max element:',maxElement)
print('min element:',minElement)

```

    max element: 605
    min element: 100
    


```python

```
